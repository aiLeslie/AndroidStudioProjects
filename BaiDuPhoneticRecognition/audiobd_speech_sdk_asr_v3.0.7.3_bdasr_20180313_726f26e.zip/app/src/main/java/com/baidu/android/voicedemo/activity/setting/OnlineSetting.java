package com.baidu.android.voicedemo.activity.setting;

import com.baidu.speech.recognizerdemo.R;

/**
 * Created by fujiayi on 2017/6/24.
 */

public class OnlineSetting extends CommonSetting {
    {
        setting =  R.xml.setting_online;
        title = "在线识别设置";
    }
}

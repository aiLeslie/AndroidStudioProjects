function getDestinationUrl() {
  var pos = window.location.href.indexOf("?url=");
  if (pos === -1) { return false; }
  return window.location.href.substring(pos + 5);
}

$(document).ready(function(){
  $('.login_form').submit(function() {
    $.ajax({
      dataType: 'jsonp',
      isLocal: true,
      cache: false,
      url: '//self/login/execute?email=' + $('#email').val() + '&password=' + $("#password").val() + '&callback=?',
      success: function(data) {
        if (data && data.error) {
          $("#error_text").html(data.error.body);
        }
        else if (data && (data.session_key || data['session_ḱey'])) {
          var sessionQuery = "&session_key=" + (data.session_key || data['session_ḱey']);

          var destUrl = getDestinationUrl();
          if (destUrl) {
            window.location.href = destUrl + sessionQuery;
            return;
          }
          if (window.location.href.indexOf("/login/form") !== -1) {
            window.location.href = "//self/discover";
            return;
          }
          window.location.reload();
        }
        else {
          $("#error_text").text("Invalid response from service");
        }
      },
      error: function(jqxhr, textStatus) {
        $("#error_text").text("Invalid response from service");
      }
    });
    return false;
  });
});


function getHTTPObject() {
        var http = false;
        //Use IE's ActiveX items to load the file.
        if(typeof ActiveXObject != 'undefined') {
                try {http = new ActiveXObject("Msxml2.XMLHTTP");}
                catch (e) {
                        try {http = new ActiveXObject("Microsoft.XMLHTTP");}
                        catch (E) {http = false;}
                }
        //If ActiveX is not available, use the XMLHttpRequest of Firefox/Mozilla etc. to load the document.
        } else if (XMLHttpRequest) {
                try {http = new XMLHttpRequest();}
                catch (e) {http = false;}
        }
        return http;
}

function setHomePage(prefix, url) {
    var ajaxRequest = getHTTPObject();
    ajaxRequest.onreadystatechange = function() {
        if (ajaxRequest.readyState == 4) {
            window.location = url;
        }
    };
    if (ajaxRequest) {
        ajaxRequest.open("GET", "//self/set_home_page?url=" + addPrefixIfNecessary(prefix, url), true);
        ajaxRequest.send(null); 
    } else {
        // alert("FAIL");
    }
}

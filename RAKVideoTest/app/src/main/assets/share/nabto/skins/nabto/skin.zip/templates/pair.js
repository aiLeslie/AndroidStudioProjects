function setHomePageAndPair(host, email) {
    var ajaxRequest = getHTTPObject();
    if (ajaxRequest) {
        ajaxRequest.onreadystatechange = function() {
            if (ajaxRequest.readyState == 4) {
                pair(host, email);
            }
        };
        ajaxRequest.open("GET", "//self/set_home_page?url=nabto://" + host, true);
        ajaxRequest.send(null); 
    } else {
        // alert("FAIL");
    }
}

function pair(host, email) {
    window.location = "//" + host + "/attempt_pair.tpt?email=" + email;
}



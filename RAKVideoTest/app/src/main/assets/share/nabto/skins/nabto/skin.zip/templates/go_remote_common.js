if ($.QueryString["prep_host"]) {
    $('#remote_host_field').val($.QueryString["prep_host"]);
    if ($.QueryString["session_key"]) {
	prep_host();
    }
} 

function prep_host() {
    $.ajax({
	dataType: 'jsonp',
    isLocal: true,
	url: '//self/install_html_dd?host=' + $('#remote_host_field').val() + '&session_key=' + session_key,
	success: function(data) { 
	    if (data.success === "true") {
		$('#status').text("Successfully installed client bundle for offline use!");
		$('#status').fadeIn(500);
	    } else {
		$('#status').text("Client bundle could not be downloaded for this host");
		$('#status').fadeIn(500);
	    }
	},
	error: function() {
	    $('#status').text("Client bundle could not be installed");
	    $('#status').fadeIn(500);
	}
    });
}

$('#remote_prepare_go').click(function() {
    var remoteHost = $('#remote_host_field').val();
    if (!remoteHost) {
        $('#remote_host_field').focus();
        $('#status').text("Please enter the address of a device");
        $('#status').fadeIn(500);
        return true;
    }
    
    var key = $.QueryString["session_key"];
    if (typeof(key) == "undefined") {
        var url = '//self/discover?prep_host=' + remoteHost;
        window.location = '//self/login/form?url=' + url;
    } else {
        prep_host();
    }
});

function go_remote() {
    var host = $('#remote_host_field').val();
    if (host !== "") {
        $.mobile.pageLoadErrorMessage = "";
        window.location = addPrefixIfNecessary(prefix, $('#remote_host_field').val() + createSessionKeyString());
    }
};
$('#remote_host_go').click(function() {
    go_remote();
});
$("#remote_host_field").keypress(function(e) {
    if (e.which == 13) {
      go_remote();
    }
});
